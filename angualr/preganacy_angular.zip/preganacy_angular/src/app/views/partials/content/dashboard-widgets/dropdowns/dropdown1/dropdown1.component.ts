// Angular
import { Component } from '@angular/core';

@Component({
  selector: 'kt-dropdown1',
  templateUrl: './dropdown1.component.html'
})
export class Dropdown1Component {
}
