// Angular
import { Component, Input } from '@angular/core';

@Component({
  selector: 'kt-widget3-authors',
  templateUrl: './widget3-authors.component.html'
})
export class Widget3NewArrivalsAuthorsComponent {
  @Input() cssClasses = '';
}
