import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
	selector: 'kt-material',
	templateUrl: './material.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class MaterialComponent { }


