import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-error2',
  templateUrl: './error2.component.html',
  styleUrls: ['./error2.component.scss']
})
export class Error2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
